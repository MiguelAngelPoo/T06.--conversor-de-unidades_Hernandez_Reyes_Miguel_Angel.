﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Convertidos_de_unidades
{
    class Program
    {
        static void Main(string[] args)
        {
            //instanciamos y mandamos a llamar
            Principal PR = new Principal();
            PR.capturardatos();
        }
    }
}
